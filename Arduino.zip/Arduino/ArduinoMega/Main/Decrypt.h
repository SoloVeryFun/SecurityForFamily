#include <Arduino.h>
#include <ArduinoJson.h>

class Decrypt{
  public:
    String decrypting(String key, String encrycode);
};